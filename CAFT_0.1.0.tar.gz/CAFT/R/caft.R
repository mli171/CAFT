#' Rank-Based Compositional Analysis using Log-Linear Models for Microbiome Data with Zero Cells
#'
#' @description This is a statistical framework for differential abundance
#'  analysis of microbiome data, termed the Compositional Accelerated Failure
#'  Time (CAFT) model. The CAFT model addresses zero read counts by treating
#'  them as censored observations below the detection limit, similar to
#'  censoring mechanisms employed in survival analysis. This approach is
#'  inherently resistant to multiplicative bias, eliminates the need for
#'  pseudocounts, and addresses compositional bias through the
#'  establishment of appropriate score test procedures.
#'
#' In addition to the default asymptotic CAFT inference, the function optionally
#' provides bootstrap calibration of taxon-level p-values. Bootstrap calibration
#' is mainly intended as a sensitivity analysis or preferred calibration method
#' when the number of taxa is small in the data set.
#'
#' @param otu.table The community OTU table (or taxa count table). Each row
#'  corresponds to a sample and each column corresponds to one OTU (taxa).
#' @param x.test Covariate(s) of interest. This can be a vector, matrix, or data
#'  frame. Multi-level categorical variables should be coded as indicator
#'  variables before input. Use \code{x.test} together with \code{x.adj} when
#'  the default hypothesis matrix \code{Gamma} is desired.
#' @param x.adj Covariates that need to be adjusted. Requirements are the
#'  same as \code{x.test} above. Use if default \code{Gamma} is desired.
#' @param x Optional design matrix containing all covariates.
#'  Default value is \code{NULL}. Only used
#'  if matrix \code{Gamma} is provided as input. It can be a vector, matrix,
#'  or dataframe. All K-level categorical variables should be converted to K-1
#'  indicator variables before input.
#' @param Gamma Optional hypothesis matrix specifying the linear combinations
#'  of regression coefficients to be tested. Not used if data are entered as
#'  \code{x.test} and \code{x.adj}.
#' @param b Optional numeric vector specifying the right-hand side of the null
#'  hypothesis \eqn{H_0: \Gamma \beta_j = b}. Its length must equal the number
#'  of rows of \code{Gamma}. If \code{b = NULL}, CAFT uses the median-based
#'  null value estimated across taxa.
#' @param filter.thresh A real value between 0 and 1 for OTU table sample
#'  presence filtering. Any OTUs present in fewer than \code{filter.thresh}
#'  proportion of samples are filtered out. We set the default to be 0.05.
#' @param fdr.nominal The nominal false discovery rate (FDR). The default is
#'  \code{0.20}.
#' @param adjust.method A character string. Use multiple comparison/testing
#'  adjustment methods to control the family-wise error rate/false discovery
#'  rate. Default is \code{"BH"}. See \code{\link{p.adjust}} for the details.
#' @param regularize A logical value. If \code{TRUE}, adds a small penalty to the
#'  rank-based score to stabilize estimation and reduce small-sample bias. Use
#'  this when the unpenalized rank equations have flat directions, there is
#'  near-separation, heavy censoring/ties, or the optimizer fails to converge.
#'  Default is \code{TRUE}.
#' @param test.method A character string. The variance estimator used to estimate
#'  the variance of the score equation. The methods of \code{"Cox"},
#'  \code{"rank"}, and \code{"martingale"} are available. Default is
#'  \code{"rank"}.
#' @param n.cores Integer. Number of CPU cores to use for parallel computation.
#'  Default is \code{1} (no parallelism). If \code{n.cores > 1}, the function
#'  runs tasks in parallel using \code{foreach}/\code{doParallel} with a PSOCK
#'  cluster. On typical desktops/laptops, a good choice is
#'  \code{max(1L, parallel::detectCores() - 1L)}.
#' @param boot.B Integer. Number of bootstrap replicates used for empirical
#'  calibration of taxon-level p-values. The default is \code{0L}, which
#'  disables bootstrap calibration. At least two bootstrap replicates are
#'  required for bootstrap calibration.
#' @param boot.parallel Logical. If \code{TRUE} and \code{boot.B >= 2}, the
#'  bootstrap loop is parallelized over bootstrap replicates. The default is
#'  \code{FALSE}.
#' @param boot.n.cores Integer. Number of CPU cores used for outer bootstrap
#'  parallelization when \code{boot.parallel = TRUE}. The default is
#'  \code{1L}.
#' @param boot.seed Optional integer seed for reproducible bootstrap resampling.
#'  The default is \code{NULL}.
#' @param boot.return.dist Logical. If \code{TRUE}, return the bootstrap-centered
#'  beta distribution and the names of taxa used in the bootstrap calibration.
#'  The default is \code{FALSE}.
#' @param verbose Logical. If \code{TRUE}, progress messages are shown during
#'  bootstrap computation. The default is \code{FALSE}.
#' @param return.mr.resid Logical; if \code{TRUE}, return subject-level
#'  residual contribution matrices from the observed CAFT fit. Default is
#'  \code{FALSE}. The returned residuals are the compensated Cox-type score
#'  contributions computed by \code{mySi.no.surv()} and evaluated at the
#'  restricted estimate used in the score test.
#'
#' @details
#' CAFT fits a rank-based accelerated failure time model to the negative
#' log-relative abundance of each taxon, treating zero counts as censored values
#' below the sample-specific detection limit. The resulting taxon-specific
#' regression coefficients are compared through compositional contrasts.
#'
#' With the default \code{x.test}/\code{x.adj} interface, the function tests the
#' covariates in \code{x.test} while adjusting for the covariates in
#' \code{x.adj}. Internally, this corresponds to a default hypothesis matrix
#' \code{Gamma} selecting the columns of \code{x.test}. For more general
#' hypotheses, users may provide a full design matrix \code{x}, a hypothesis
#' matrix \code{Gamma}, and optionally a null value \code{b}, corresponding to
#' \eqn{H_0: \Gamma \beta_j = b}. If \code{b = NULL}, the null value is estimated
#' as the median-based reference across taxa.
#'
#' This wrapper implements the refactored CAFT workflow. It first calls
#' \code{caft_estimate()} to compute unrestricted taxon-level estimates, then
#' calls \code{caft_test()} to perform the restricted score test. If
#' \code{boot.B >= 2}, it further calls \code{caft_bootstrap()} for bootstrap
#' calibration. This separation allows the unrestricted estimates to be reused
#' when testing different hypotheses or different choices of \code{b}.
#'
#' When \code{boot.B >= 2}, CAFT performs fixed-design bootstrap calibration.
#' The observed model is first fit, and the bootstrap is carried out on the taxa
#' that pass the original filtering step. In each bootstrap replicate, samples
#' are resampled with replacement from the OTU table while the covariates are
#' kept fixed. The model is then refit with \code{filter.thresh = 0} on the same
#' set of taxa. Bootstrap p-values are computed from the centered bootstrap
#' distribution of the tested coefficient contrasts. For a single testing
#' variable, both a two-sided empirical beta-tilde p-value and a studentized
#' chi-square/Wald bootstrap p-value are returned. For multiple testing
#' variables, the bootstrap p-value is based on a multivariate statistic;
#' in this case \code{p.boot} and \code{p.boot.chi} are identical.
#'
#' If \code{boot.parallel = TRUE}, the outer bootstrap loop is parallelized over
#' bootstrap replicates. To avoid nested parallelism, the inner CAFT fitting
#' routine is run with \code{n.cores = 1L} inside each bootstrap worker.
#'
#' @return Return a list consisting of
#' \describe{
#' \item{beta.est}{A matrix that include the estimated coefficients by fitting
#'  each OTU count to the log-linear model. The number of columns should match
#'  the number of covariates from \code{x.test} and \code{x.adj}.}
#' \item{betahat.median}{The selected median of all betas, which was used in the
#'  restricted score test of the significance of differential abundant OTU. It
#'  can also be used to calculate the effect size of each OTU, defined as the
#'  difference from the median of all betas.}
#' \item{b.null}{The null value actually used in the restricted score test. This
#'  equals \code{betahat.median} when \code{b = NULL}, and equals the
#'  user-specified \code{b} otherwise.}
#' \item{b.user.specified}{Logical indicator of whether \code{b} was supplied
#'  by the user. If \code{FALSE}, \code{b.null} was computed as the
#'  median-based reference value. If \code{TRUE}, \code{b.null} equals the
#'  user-specified null value.}
#' \item{b.user}{The user-specified null value, returned only when \code{b} is
#'  supplied. Otherwise \code{NULL}.}
#' \item{rank.teststat}{Test statistics from the proposed score test.}
#' \item{rank.teststat.norm}{Numeric matrix with the normalized rank-based test
#'  statistics for each taxon (rows) and each tested contrast (columns, in the
#'  order of \code{Gamma}'s rows). Under the null, entries are approximately
#'  \eqn{N(0,1)}; larger absolute values indicate stronger evidence against the
#'  null.}
#' \item{skip.otu}{The names of skipped OTU during taxa presence filtering.}
#' \item{skip.rare}{Indicator for taxa skipped by the rarity filter.}
#' \item{skip.fail.rank.fit.pen}{Indicator for taxa whose unrestricted
#'  rank-based fit failed.}
#' \item{skip.fail.rank.test.pen}{Indicator for taxa whose restricted
#'  estimation or rank-based score test failed.}
#' \item{fit.error.messages}{Error messages from failed unrestricted
#'  taxon-level fits, if any.}
#' \item{fit.error.messages.test}{Error messages from failed restricted
#'  taxon-level tests, if any.}
#' \item{p.otu}{P-values for individual OTU association tests.}
#' \item{df.test}{Degrees of freedom per taxon in the test.}
#' \item{beta.est.r}{Matrix of constrained (restricted) estimates from the
#'  restricted score test.}
#' \item{p.marginal.otu}{Taxa with raw p-values smaller than
#'  \code{fdr.nominal} based on \code{p.otu}.}
#' \item{q.otu}{Q-values from adjusting p-values by the method specified in
#'  \code{adjust.method}, for individual OTU association tests.}
#' \item{q.detected.otu}{Detected significantly differential abundant taxa
#'  (denoted by the column names of the OTU table) at the nominal FDR based on
#'  \code{q.otu}.}
#' \item{p.boot}{Bootstrap-calibrated empirical beta-tilde p-values. If
#'  \code{boot.B < 2}, this is not returned.}
#' \item{q.boot}{Multiplicity-adjusted values from \code{p.boot}.}
#' \item{p.boot.detected.otu}{Taxa detected using \code{p.boot < fdr.nominal}.
#'  Empty if bootstrap calibration is not run.}
#' \item{q.boot.detected.otu}{Taxa detected using
#'  \code{q.boot < fdr.nominal}. Empty if bootstrap calibration is not run.}
#' \item{p.boot.chi}{Studentized chi-square/Wald bootstrap p-values. For
#'  multiple testing variables, these are the same as \code{p.boot}. If
#'  \code{boot.B < 2}, this is not returned.}
#' \item{q.boot.chi}{Multiplicity-adjusted values from \code{p.boot.chi}.}
#' \item{p.boot.chi.marginal.otu}{Taxa detected using
#'  \code{p.boot.chi < fdr.nominal}. Empty if bootstrap calibration is not run.}
#' \item{q.boot.chi.detected.otu}{Taxa detected using
#'  \code{q.boot.chi < fdr.nominal}. Empty if bootstrap calibration is not run.}
#' \item{boot.median}{Matrix of bootstrap null values used to center the
#'  bootstrap coefficient estimates. When \code{b} is user-specified, these
#'  values equal the specified null value across bootstrap replicates.}
#' \item{boot.n.success}{Number of bootstrap replicates that produced complete
#'  bootstrap null values.}
#' \item{boot.n.fail}{Number of bootstrap replicates skipped or failed.}
#' \item{boot.beta.tilde}{Returned only when \code{boot.return.dist = TRUE}.
#'  Array of bootstrap-centered tested coefficient contrasts.}
#' \item{boot.taxa}{Returned only when \code{boot.return.dist = TRUE}. Names of
#'  taxa used in the bootstrap calibration.}
#' \item{mr.resid}{Returned only when \code{return.mr.resid = TRUE}. A list of
#'  length equal to the number of taxa. Each element is an \eqn{n \times p}
#'  matrix of subject-level compensated Cox-type residual contributions,
#'  evaluated at the restricted estimate used in the score test.}
#' }
#'
#' @importFrom stats cov optim pchisq setNames var
#'
#' @export
#' @examples
#' data(Colon)
#'
#' count.tab <- t(as(phyloseq::otu_table(Colon), "matrix"))
#' sample.tab <- as(phyloseq::sample_data(Colon), "data.frame")
#'
#' keep.sample <- !is.na(sample.tab$age)
#' count.tab <- count.tab[keep.sample, , drop = FALSE]
#' sample.tab <- sample.tab[keep.sample, , drop = FALSE]
#'
#' keep.otu <- colSums(count.tab > 0) > 1
#' count.tab <- count.tab[, keep.otu, drop = FALSE]
#'
#' ## Use a small subset of taxa for a fast example.
#' prev <- colSums(count.tab > 0)
#' keep.top <- names(sort(prev, decreasing = TRUE))[
#'   seq_len(min(20L, length(prev)))
#' ]
#' count.tab <- count.tab[, keep.top, drop = FALSE]
#'
#' ## Remove samples with zero library size after subsetting taxa.
#' keep.lib <- rowSums(count.tab) > 0
#' count.tab <- count.tab[keep.lib, , drop = FALSE]
#' sample.tab <- sample.tab[keep.lib, , drop = FALSE]
#'
#' Disease1 <- Disease2 <- rep(0, nrow(sample.tab))
#' Disease1[sample.tab$disease == "CRC"] <- 1
#' Disease2[sample.tab$disease == "adenoma"] <- 1
#'
#' Age <- as.numeric(sample.tab$age)
#' Gender <- as.numeric(factor(sample.tab$gender)) - 1
#'
#' x.test <- cbind(CRC = Disease1, adenoma = Disease2)
#' x.adj <- cbind(Age = Age, Gender = Gender)
#'
#' ## Standard CAFT wrapper.
#' res <- caft(otu.table=count.tab, x.test=x.test, x.adj=x.adj)
#' head(res$p.otu)
#' res$q.detected.otu
#'
#' ## Separated estimation and testing workflow.
#' est <- caft_estimate(
#'   otu.table = count.tab,
#'   x.test = x.test,
#'   x.adj = x.adj
#' )
#'
#' test <- caft_test(est)
#' head(test$p.otu)
#'
#' ## Reuse the same unrestricted estimates with a user-specified null value.
#' test.b0 <- caft_test(est, b = c(0, 0))
#' test.b0$b.null
#'
#' \donttest{
#' ## Bootstrap calibration with a small number of replicates for illustration.
#' res.boot <- caft(
#'   otu.table = count.tab,
#'   x.test = x.test,
#'   x.adj = x.adj,
#'   b = c(0, 0),
#'   boot.B = 2L,
#'   boot.seed = 1L
#' )
#'
#' res.boot$boot.n.success
#' head(res.boot$p.boot)
#' }
caft <- function(otu.table,
                 x.test = NULL,
                 x.adj = NULL,
                 x = NULL,
                 Gamma = NULL,
                 b = NULL,
                 filter.thresh = 0.05,
                 fdr.nominal = 0.20,
                 adjust.method = "BH",
                 regularize = TRUE,
                 test.method = "rank",
                 n.cores = 1L,
                 boot.B = 0L,
                 boot.parallel = FALSE,
                 boot.n.cores = 1L,
                 boot.seed = NULL,
                 boot.return.dist = FALSE,
                 verbose = FALSE,
                 return.mr.resid = FALSE) {

  boot.B <- as.integer(boot.B)

  est <- caft_estimate(
    otu.table = otu.table,
    x.test = x.test,
    x.adj = x.adj,
    x = x,
    filter.thresh = filter.thresh,
    regularize = regularize,
    n.cores = n.cores
  )

  res <- caft_test(
    est = est,
    Gamma = Gamma,
    b = b,
    fdr.nominal = fdr.nominal,
    adjust.method = adjust.method,
    regularize = regularize,
    test.method = test.method,
    n.cores = n.cores,
    return.mr.resid = return.mr.resid
  )

  if (!is.na(boot.B) && boot.B >= 2L) {
    res <- caft_bootstrap(
      res = res,
      boot.B = boot.B,
      boot.parallel = boot.parallel,
      boot.n.cores = boot.n.cores,
      boot.seed = boot.seed,
      boot.return.dist = boot.return.dist,
      verbose = verbose
    )
  }

  res
}
